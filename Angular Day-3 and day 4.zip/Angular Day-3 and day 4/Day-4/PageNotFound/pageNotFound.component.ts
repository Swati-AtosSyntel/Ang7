import { Component } from '@angular/core';

@Component({
  
  template: '<h1>{{message}}</h1>'
  
})
export class PageNotFoundComponent {
  message = 'Page Not Found!';
}
