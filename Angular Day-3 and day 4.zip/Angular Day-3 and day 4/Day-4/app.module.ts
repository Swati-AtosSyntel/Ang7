import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {RouterModule,Routes} from '@angular/router';
import { AppComponent } from './app.component';
import {EmployeeService} from './employeeList/employeeservice.service';
import {EmployeeListComponent} from './employeeList/employeeList.component';
import {HomeComponent} from './Home/home.component';
import {PageNotFoundComponent} from './PageNotFound/pageNotFound.component';
const appRoutes:Routes=[
  {path:"home",component:HomeComponent},
  {path:"employees",component:EmployeeListComponent},
  {path:"",redirectTo:'/home', pathMatch:'full'},
  {path:"**",component:PageNotFoundComponent}
]


@NgModule({
  declarations: [
    AppComponent,EmployeeListComponent,HomeComponent,PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
