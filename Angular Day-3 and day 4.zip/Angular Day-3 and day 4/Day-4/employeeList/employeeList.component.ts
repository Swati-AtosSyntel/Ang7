import { Component,OnInit } from '@angular/core';
import {IEmployee} from './employee';
import {EmployeeService} from './employeeservice.service';
import {Observable} from 'rxjs/observable';
@Component({
  selector: 'app-employeeList',
  templateUrl: './employeeList.component.html',
  providers:[EmployeeService]
  
})
export class EmployeeListComponent {
  employees:IEmployee[];
 statusMessage:string="Loading Data ....Please wait....";
  constructor(private _employeeService:EmployeeService){
    
  }
  ngOnInit(){
   this._employeeService.getEmployees()
   .subscribe((employeeData)=>this.employees=employeeData,
   error=>{this.statusMessage="Some error ocurred in the service.Please try again later";
   console.log(error);

   })
  }
  
} 
