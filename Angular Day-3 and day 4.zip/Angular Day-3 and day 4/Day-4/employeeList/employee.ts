

export interface IEmployee{
    eid:number;
    ename:string;
    Department:string;
    location:string;

}

